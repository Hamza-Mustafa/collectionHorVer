//
//  FastModel.swift
//  collectionHorVer
//
//  Created by Hamza Mustafa on 14/10/2020.
//

import Foundation

class FastModel{
    var title : String?
    required init?() {
    }
}
