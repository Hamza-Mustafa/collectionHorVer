//
//  DesiModel.swift
//  collectionHorVer
//
//  Created by Hamza Mustafa on 15/10/2020.
//

import Foundation

class DesiModel{
    var title : String?
    required init?(){
    }
}
