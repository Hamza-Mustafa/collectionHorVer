//
//  DesiCollectionViewCell.swift
//  collectionHorVer
//
//  Created by Hamza Mustafa on 15/10/2020.
//

import UIKit

class DesiCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imgDataDesi: UIImageView!
    @IBOutlet weak var imgTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
