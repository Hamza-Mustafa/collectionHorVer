//
//  DesiViewController.swift
//  collectionHorVer
//
//  Created by Hamza Mustafa on 15/10/2020.
//

import UIKit

class DesiViewController: UICollectionViewController {
    
    var desiProducts : [DesiDataModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateData()
        //desi Collection View
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 20, left: 10, bottom: 10, right: 10)
        layout.itemSize = CGSize(width: 60, height: 60)
        layout.scrollDirection = .horizontal
        self.collectionView = UICollectionView(frame: self.collectionView.frame, collectionViewLayout: layout)
       
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        let nibCell = UINib(nibName: "DesiCollectionViewCell", bundle: nil)
        self.collectionView.register(nibCell, forCellWithReuseIdentifier: "DesiCollectionViewCell")
        
        self.collectionView.backgroundColor = UIColor.white
        self.collectionView.showsHorizontalScrollIndicator = true
        self.collectionView.reloadData()
        self.collectionView.setNeedsLayout()
        self.collectionView.layoutIfNeeded()
    }
    
    func populateData() {
        desiProducts = [
            DesiDataModel(title: "demo1", image: #imageLiteral(resourceName: "desi2")),DesiDataModel(title: "demo2", image: #imageLiteral(resourceName: "desi")),DesiDataModel(title: "demo3", image: #imageLiteral(resourceName: "desi2")),
            DesiDataModel(title: "demo4", image: #imageLiteral(resourceName: "desi")),DesiDataModel(title: "demo5", image: #imageLiteral(resourceName: "desi2"))
        ]
    }
    
    init() {
            super.init(collectionViewLayout: UICollectionViewFlowLayout())
        }
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
}

extension DesiViewController : UICollectionViewDelegateFlowLayout {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return desiProducts.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DesiCollectionViewCell", for: indexPath) as! DesiCollectionViewCell
        cell.model = desiProducts[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 400, height: 160)
    }
}
