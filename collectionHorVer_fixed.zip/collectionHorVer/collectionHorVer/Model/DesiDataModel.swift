//
//  DesiDataModel.swift
//  collectionHorVer
//
//  Created by Hamza Mustafa on 16/10/2020.
//

import Foundation
import UIKit

class DesiDataModel{
    var title : String?
    let desiImage : UIImage
    required init(title: String,image:UIImage) {
        self.title = title
        self.desiImage = image
    }
}
