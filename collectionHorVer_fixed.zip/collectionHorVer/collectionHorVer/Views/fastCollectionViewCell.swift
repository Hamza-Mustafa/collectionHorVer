//
//  fastCollectionViewCell.swift
//  collectionHorVer
//
//  Created by Hamza Mustafa on 14/10/2020.
//

import UIKit

class fastCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imgData: UIImageView!
    @IBOutlet weak var imgTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
