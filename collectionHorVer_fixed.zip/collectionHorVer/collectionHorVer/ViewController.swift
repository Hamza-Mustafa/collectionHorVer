//
//  ViewController.swift
//  collectionHorVer
//
//  Created by Hamza Mustafa on 14/10/2020.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    let fastCellId = "fastCollectionViewCell"
    var fastProducts = [FastModel]()
    let fastImgsArray = [ #imageLiteral(resourceName: "1") ,#imageLiteral(resourceName: "2") ,#imageLiteral(resourceName: "1") ,#imageLiteral(resourceName: "2") ,#imageLiteral(resourceName: "1")]
    var desiController: DesiViewController?
    
    var leftAnchor : NSLayoutConstraint?
    var rightAnchor : NSLayoutConstraint?
    var topAnchor : NSLayoutConstraint?
    var bottomAnchor : NSLayoutConstraint?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let nibCell = UINib(nibName: fastCellId, bundle: nil)
        collectionView.register(nibCell, forCellWithReuseIdentifier: fastCellId)
        
        for index in 1...5 {
            let product = FastModel()
            product?.title = "Biryani \(index)"
            fastProducts.append(product!)
        }
        collectionView.reloadData()
    }
}

extension ViewController: UICollectionViewDataSource , UICollectionViewDelegate , UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if(section==0){
            return 1
        }
        else{
            return fastProducts.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        switch indexPath.section {
        case 0:
            // embed collectionview contrller into cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell1", for: indexPath)
            self.desiController = DesiViewController()
            
//            topAnchor =  self.desiController?.collectionView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor)
//            leftAnchor = self.desiController?.collectionView.leftAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.leftAnchor)
//            rightAnchor = self.desiController?.collectionView.rightAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.rightAnchor)
//            bottomAnchor = self.desiController?.collectionView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor)
//
//            topAnchor?.isActive = true
//            leftAnchor?.isActive = true
//            rightAnchor?.isActive = true
//            bottomAnchor?.isActive = true
                    
            addChild(desiController!)
            cell.contentView.addSubview((desiController?.view)!)
            desiController?.didMove(toParent: self)
            return cell
        case 1:
            // return oterh cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: fastCellId, for: indexPath) as! fastCollectionViewCell
            let product = fastProducts[indexPath.row]
            cell.imgData.image = fastImgsArray[indexPath.row]
            cell.imgTitle.text = product.title
            
            return cell
        default:
            return UICollectionViewCell()
        }
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let section = indexPath.section
        if(section==0){
            return CGSize(width: UIScreen.main.bounds.width, height: 200)
        }
        else{
            return CGSize(width: UIScreen.main.bounds.width, height: 150)
        }
    }
}
